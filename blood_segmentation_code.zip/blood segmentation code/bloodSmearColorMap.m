% Rewrite session file and create ground truth data source
%
% Copyright 2018 The MathWorks, Inc.
function cmap = bloodSmearColorMap()

cmap = [
    128 128 128   % Background
    000 000 192   % BloodCells
    128 000 000   % BloodParasites 
    ];

cmap = cmap ./ 255;
end