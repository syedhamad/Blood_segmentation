%%
clc;
clear;
% return;


% % %% Reading Images and Mask
% % Oimg = imread('O.jpg');
% % RM = imread('RM.jpg');
% % WM = imread('WM.jpg');
% % PM = imread('PM.jpg');


Oimgds = imageDatastore('Dataset/Original_img');
Platletsds = imageDatastore('Dataset/Platlets_Mask');
RBCsds = imageDatastore('Dataset/RBCsMask');
WBCsds = imageDatastore('Dataset/WBCsMask');

for i=1:numel(Oimgds.Files)
    
    Oimg = imread(string(Oimgds.Files(i)));
    RM = imread(string(RBCsds.Files(i)));
    WM = imread(string(WBCsds.Files(i)));
    PM = imread(string(Platletsds.Files(i)));

    
    %% RGB Check
    if size(RM,3) >1
        RM = rgb2gray(RM);
    end
    
    if size(PM,3) >1
        PM = rgb2gray(PM);
    end
    
    if size(WM,3) >1
        WM = rgb2gray(WM);
    end
    
    
    
    
    
    %% Fusing Mask Pixel Labeling
    MaskAll = uint8(zeros([size(Oimg,1) size(Oimg,2)]));

    %% Complement Images Mask
    PM = imcomplement(PM);
    WM = imcomplement(WM);
    RM = imcomplement(RM);


    %% Uinty Mask
    RM = RM./RM;
    WM = WM./WM;
    PM = PM./PM;

    %% Masking Value Replacement
    MaskAll(find(RM>0)) = 1;
    MaskAll(find(WM>0)) = 2;
    MaskAll(find(PM>0)) = 3;

    %% Write  Images
    imwrite(MaskAll,strcat("images/PixelLabelData/Label_",string(i),".png"));
    imwrite(Oimg,strcat("images/Img_",string(i),".jpg"));
    
    %% Resizing
    Oimg = imresize(Oimg,[300,300]);
    MaskAll = imresize(MaskAll,[300,300]);

    %% Write resized  Images
    imwrite(MaskAll,strcat("images/labelsResized/Label_",string(i),".png"));
    imwrite(Oimg,strcat("images/imagesReszed/Img_",string(i),".jpg"));
disp(i);
end